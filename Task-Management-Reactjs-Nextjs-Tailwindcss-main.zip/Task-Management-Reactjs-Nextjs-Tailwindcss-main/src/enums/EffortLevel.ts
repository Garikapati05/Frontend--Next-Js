export enum EffortLevel {
  EASY,
  MODERATE,
  HARD,
}
